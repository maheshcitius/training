export const ManagepatientRecords = () => {
    return <h2>Manage Patients</h2>;

};