export const ManagePhysician = () => {
    return <h2>Manage Physician</h2>;

};