export const AdminManagePhysicians = () => {
    return <h2>Manage physician from Admin</h2>;

};