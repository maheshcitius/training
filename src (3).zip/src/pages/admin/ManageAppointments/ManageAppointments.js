export const ManageAppointments = () => {
    return <h2>Manage Appointments</h2>;

};