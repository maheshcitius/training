import PatientDemographics from '../../pages/patient/demographics'


export const ManagePatients = () => {
    return <div><PatientDemographics/></div>;

};