export const ManagePhysicianPatients = ()  =>        
 {

 return <h2>Manage Patients </h2>;


 };