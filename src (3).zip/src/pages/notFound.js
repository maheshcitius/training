import {
  Box,
  Container,
  Typography
} from '@mui/material';
import SchedulingEvents from '../components/SchedulingEvents'

const NotFound = () => (
  <>
  
    
          <SchedulingEvents/>
     
  </>
);

export default NotFound;
