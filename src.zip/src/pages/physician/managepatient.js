export const ManagePhysicianPatients = ()  =>        
 {

 return <h2>Manage Patients from physician</h2>;


 };