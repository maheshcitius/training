export const PhysicianDashboard = () => {
    return <h2>Physician Dashboard</h2>;
  
}


