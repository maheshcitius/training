import React, {  useEffect, useState } from 'react';
import CssBaseline from '@mui/material/CssBaseline';
import Link from '@mui/material/Link';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { useDispatch, useSelector } from "react-redux";
import { bindActionCreators } from 'redux'
import { immunizationActions } from '../../actions'
import  ImmunizationForm from '../../shared/ImmunizationForm'
import { date } from 'yup/lib/locale';

function Copyright(props) {
  return (
    <Typography variant="body2" color="text.secondary" align="center" {...props}>
      {'Copyright © '}
      <Link color="inherit" href="/">
        Your Website
      </Link>{' '}
      {new Date().getFullYear()}
      {'.'}
    </Typography>
  );
}

const theme = createTheme();

export const PatientImmunizations = (props) => {
  const dispatch = useDispatch();

  const UserInfo = useSelector((state) => state);
  const [immArr, setimmArr] = useState([]);
  const { postImmunization } = bindActionCreators(immunizationActions, dispatch);
  const { getAll } = bindActionCreators(immunizationActions, dispatch);
  console.log(UserInfo);
  useEffect(() => {
    getAll();
    setimmArr(UserInfo.immunization.immunization)
  }, [])
  console.log(immArr);
  

  const handleSubmit = (values) => {
    const payload={
      patientID: UserInfo.authentication.user.user.id,
      vaccineType:values.vaccineType,
      vaccineName:values.vaccineName,
      noOfDoses:values.noOfDoses,
      vaccinatedOn:values.vaccinatedOn,
      createdBy: UserInfo.authentication.user.user.firstname+ " " + UserInfo.authentication.user.user.lastname,
      createdOn: new Date(),
      updatedBy:UserInfo.authentication.user.user.firstname+ " " + UserInfo.authentication.user.user.lastname,
      updatedOn:new Date(),
      isActive: true,
      };
      console.log(payload);

    postImmunization(payload);
    // setimmArr(UserInfo.immunization.immunization);
    // console.log(immArr);

  };

  return (
    <ThemeProvider theme={theme}>
        <CssBaseline />
        <Box
          sx={{
            marginTop: 0,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            height: "100vh"
          }}
        >         
          <Typography component="h1" variant="h5">
           Patient Immunizations         
           </Typography>
          <ImmunizationForm handleSubmit={handleSubmit}/>
        </Box>
    </ThemeProvider>
  
  );
};
