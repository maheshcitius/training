export const ManagePatients = () => {
    return <h2>Manage Patients</h2>;

};