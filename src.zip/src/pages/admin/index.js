export  const AdminDashboard = (props) => {
    

    return (
        <>
                <h3>Admin Dashboard</h3>
             
                    { props.children }

        </>
    );

};