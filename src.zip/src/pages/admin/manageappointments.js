export const AdminManageAppointments = () => {
    return <h2>Manage Appointments from Admin</h2>;

};