export const Billing = () => {
    return <h2>Billing</h2>;

};