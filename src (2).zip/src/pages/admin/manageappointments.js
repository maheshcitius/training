
import { Box , Container, Typography } from '@mui/material';

import Page from '../../shared/Page';

export const  AdminManageAppointments =()=> {
    return (
        <Page title="Patient | Appointments">
        <Container maxWidth="xl">
          <Box sl={{ pb: 5 }}>
            <Typography variant="h4">Hi, Welcome to Admin Appointments</Typography>
          </Box>
          </Container>
          </Page>
             )
    

};
